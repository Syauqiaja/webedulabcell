<div class="d-flex">
    <a href="{{ route('user.detail', ['user' => $user->id]) }}" class="btn btn-sm btn-outline-primary ms-1" wire:navigate><i class="bi bi-eye"></i> Lihat</a>
</div>