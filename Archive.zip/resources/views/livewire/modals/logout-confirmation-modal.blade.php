<div class="p-5 text-center">
    <h4 class="h4">Apakah anda ingin logout?</h4>
    <div class="row mt-3 align-items-end">
        <div class="col-3">
            <button class="btn btn-outline-secondary">Batal</button>
        </div>
        <div class="col-3">
            <button class="btn btn-danger">Logout</button>
        </div>
    </div>
</div>
