<div class="p-3 bg-white row mx-0">
    <div class="col-lg-8">
        <h4 class="h3">{{$title}}</h4>
        <span>{{$description}}</span>
    </div>
    <div class="col-lg-4 text-end">
        {{ $slot }}
    </div>
</div>