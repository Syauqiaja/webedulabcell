<?php

namespace App\Livewire\Activities\Components;

use Livewire\Component;

class ActivityItem extends Component
{
    public function render()
    {
        return view('components.activity-item');
    }
}
